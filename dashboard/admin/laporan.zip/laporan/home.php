<div class="container mt-4">
    <!-- Form Filter -->
    <form method="GET" class="form-inline mb-4 row g-2 align-items-end">
        <div class="col-auto">
            <label for="start_date">Dari Tanggal:</label>
            <input type="date" name="start_date" id="start_date" class="form-control"
                value="<?= isset($_GET['start_date']) ? htmlspecialchars($_GET['start_date']) : '' ?>">
        </div>
        <div class="col-auto">
            <label for="end_date">Sampai Tanggal:</label>
            <input type="date" name="end_date" id="end_date" class="form-control"
                value="<?= isset($_GET['end_date']) ? htmlspecialchars($_GET['end_date']) : '' ?>">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-primary">Tampilkan</button>

            <?php
            // Ambil parameter tanggal
            $start_date = $_GET['start_date'] ?? '';
            $end_date = $_GET['end_date'] ?? '';

            // Cek apakah ada data
            $where = "WHERE 1=1";
            if (!empty($start_date)) {
                $where .= " AND DATE(r.created_at) >= '$start_date'";
            }
            if (!empty($end_date)) {
                $where .= " AND DATE(r.created_at) <= '$end_date'";
            }

            $cek_sessions = mysqli_query($koneksidb, "
        SELECT COUNT(DISTINCT r.session_id) as jumlah
        FROM results r
        $where
    ");
            $rowCek = mysqli_fetch_assoc($cek_sessions);
            $adaData = $rowCek['jumlah'] > 0;

            if ($adaData): ?>
                <a href="cetak-laporan.php?start_date=<?= $start_date ?>&end_date=<?= $end_date ?>" target="_blank"
                    class="btn btn-danger">
                    <i class="fas fa-file-pdf"></i> Cetak PDF
                </a>
            <?php endif; ?>
        </div>

    </form>

    <?php
    // Ambil semua session unik yang sesuai filter
    $sessions = mysqli_query($koneksidb, "
        SELECT DISTINCT r.session_id, DATE(r.created_at) as tanggal
        FROM results r
        $where
        ORDER BY tanggal DESC
    ");

    if (mysqli_num_rows($sessions) === 0): ?>
        <div class="alert alert-warning">
            Tidak ada data perhitungan ditemukan untuk filter yang dipilih.
        </div>
        <?php
    else:
        $batch_no = 1;
        while ($s = mysqli_fetch_assoc($sessions)):
            $sid = $s['session_id'];
            $tanggal = $s['tanggal'];
            echo "<h5 class='mt-4'>Batch #$batch_no | Tanggal: $tanggal</h5>";
            $batch_no++;

            $ranking = mysqli_query($koneksidb, "
                SELECT r.*, a.code, a.name 
                FROM results r
                JOIN alternatives a ON r.alternative_id = a.id
                WHERE r.session_id = '$sid'
                ORDER BY r.ranking ASC
            ");
            ?>

            <table class="table table-bordered table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Peringkat</th>
                        <th>Kode</th>
                        <th>Nama Alternatif</th>
                        <th>Nilai Preferensi (Y<sub>i</sub>)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($ranking)): ?>
                        <tr>
                            <td><?= $row['ranking'] ?></td>
                            <td><?= htmlspecialchars($row['code']) ?></td>
                            <td>
                                <?= htmlspecialchars($row['name']) ?>
                                <?= $row['ranking'] == 1 ? "<span class='badge bg-success'>Terbaik</span>" : "" ?>
                            </td>
                            <td><?= $row['preference_value'] ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

        <?php endwhile; ?>
    <?php endif; ?>
</div>