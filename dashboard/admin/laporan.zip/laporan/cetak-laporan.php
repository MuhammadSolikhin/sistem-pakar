<?php
include '../../../config/koneksi.php';

// Ambil parameter tanggal dari URL
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';

// Filter query berdasarkan tanggal jika tersedia
$where = "WHERE 1=1";
if (!empty($start_date)) {
    $where .= " AND DATE(r.created_at) >= '$start_date'";
}
if (!empty($end_date)) {
    $where .= " AND DATE(r.created_at) <= '$end_date'";
}

// Ambil data sesi unik yang sesuai filter
$sessions = mysqli_query($koneksidb, "
    SELECT DISTINCT r.session_id, DATE(r.created_at) as tanggal
    FROM results r
    $where
    ORDER BY tanggal DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Laporan Perhitungan</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 14px; }
        h2, h4 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 6px; text-align: left; }
        .badge { color: white; background-color: green; padding: 2px 6px; border-radius: 4px; font-size: 12px; }
    </style>
</head>
<body>

<h2>Laporan Hasil Perhitungan</h2>
<h4>
    <?php if (!empty($start_date) && !empty($end_date)): ?>
        Periode: <?= date('d/m/Y', strtotime($start_date)) ?> - <?= date('d/m/Y', strtotime($end_date)) ?>
    <?php else: ?>
        Semua Data
    <?php endif; ?>
</h4>
<hr>

<?php
if (mysqli_num_rows($sessions) === 0) {
    echo "<p>Tidak ada data yang ditemukan untuk periode tersebut.</p>";
} else {
    $batch_no = 1;
    while ($s = mysqli_fetch_assoc($sessions)) {
        $sid = $s['session_id'];
        $tanggal = $s['tanggal'];
        echo "<h4>Batch #$batch_no | Tanggal: " . date('d/m/Y', strtotime($tanggal)) . "</h4>";

        $ranking = mysqli_query($koneksidb, "
            SELECT r.*, a.code, a.name 
            FROM results r
            JOIN alternatives a ON r.alternative_id = a.id
            WHERE r.session_id = '$sid'
            ORDER BY r.ranking ASC
        ");

        echo "<table>
                <thead>
                    <tr>
                        <th>Peringkat</th>
                        <th>Kode</th>
                        <th>Nama Alternatif</th>
                        <th>Nilai Preferensi</th>
                    </tr>
                </thead>
                <tbody>";

        while ($row = mysqli_fetch_assoc($ranking)) {
            echo "<tr>
                    <td>{$row['ranking']}</td>
                    <td>" . htmlspecialchars($row['code']) . "</td>
                    <td>" . htmlspecialchars($row['name']);
            if ($row['ranking'] == 1) {
                echo " <span class='badge'>Terbaik</span>";
            }
            echo "</td>
                    <td>{$row['preference_value']}</td>
                </tr>";
        }

        echo "</tbody></table><br>";
        $batch_no++;
    }
}
?>

<script>
    // Auto print saat dibuka
    window.onload = function () {
        window.print();
    };
</script>

</body>
</html>
